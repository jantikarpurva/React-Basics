import React from "react";

let MessageContext = React.createContext({});

export default MessageContext;